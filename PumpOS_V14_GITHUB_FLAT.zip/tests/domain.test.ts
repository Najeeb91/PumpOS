import assert from "node:assert/strict";
import test from "node:test";
import { calculateVariance } from "../lib/reconciliation";
import { Prisma } from "@prisma/client";

test("no tolerance: 0.001 L is a variance", () => {
  assert.equal(calculateVariance(new Prisma.Decimal("100"), new Prisma.Decimal("99.999"), new Prisma.Decimal("0")).toFixed(3), "0.001");
});

test("no tolerance: exact zero reconciles", () => {
  assert.equal(calculateVariance(new Prisma.Decimal("100"), new Prisma.Decimal("95"), new Prisma.Decimal("5")).toFixed(3), "0.000");
});

test("negative raw meter movement is not silently treated as zero", () => {
  assert.notEqual(calculateVariance(new Prisma.Decimal("90"), new Prisma.Decimal("100"), new Prisma.Decimal("0")).toFixed(3), "0.000");
});
