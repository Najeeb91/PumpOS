import assert from "node:assert/strict";
import test from "node:test";
import { expectedCash, fuelVariance, paymentsMatchSale, sumMoney } from "../lib/financial";

test("money sum handles paise", () => assert.equal(sumMoney(["10.10", "20.25", "0.05"]), "30.40"));
test("split payments must equal sale", () => {
  assert.equal(paymentsMatchSale("1000.00", [{method:"CASH",amount:"400"},{method:"UPI",amount:"600"}]), true);
  assert.equal(paymentsMatchSale("1000.00", [{method:"CASH",amount:"400"},{method:"UPI",amount:"599.99"}]), false);
});
test("expected cash formula", () => assert.equal(expectedCash({openingCash:"500",cashSales:"2500",cashRefunds:"100",expenses:"200",cashIn:"50",adjustments:"0"}), "2750.00"));
test("fuel variance is exact zero when controlled", () => assert.equal(fuelVariance("1000", "1200", "195", "5"), "0.000"));
test("fuel variance detects even tiny non-zero difference", () => assert.equal(fuelVariance("1000", "1200", "195.001", "5"), "-0.001"));
