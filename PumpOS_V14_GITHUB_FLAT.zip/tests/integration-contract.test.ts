import test from "node:test";
import assert from "node:assert/strict";

function variance(meter: number, sales: number, nonSale: number) {
  return meter - sales - nonSale;
}

function expectedCash(opening: number, cashSales: number, refunds: number, expenses: number, cashIn: number, adjustments: number) {
  return opening + cashSales - refunds - expenses + cashIn + adjustments;
}

test("happy path: exact fuel reconciliation can proceed to approval", () => {
  const petrol = variance(1010, 10, 0);
  const diesel = variance(2025, 25, 0);
  assert.equal(petrol, 0);
  assert.equal(diesel, 0);
  assert.equal(petrol === 0 && diesel === 0, true);
});

test("fuel variance blocks submission", () => {
  const v = variance(1010, 9.999, 0);
  assert.notEqual(v, 0);
});

test("approved non-sale dispensing is included in reconciliation", () => {
  const v = variance(1020, 19, 1);
  assert.equal(v, 0);
});

test("cash is calculated from cash payment stream, not total sale value", () => {
  // ₹1,000 split as ₹600 cash + ₹400 UPI: only ₹600 enters expected cash.
  assert.equal(expectedCash(5000, 600, 0, 100, 0, 0), 5500);
});

test("cash difference requires explanation before submission", () => {
  const expected = expectedCash(5000, 600, 0, 100, 0, 0);
  const actual = 5400;
  const difference = actual - expected;
  assert.equal(difference, -100);
  assert.notEqual(difference, 0);
});

test("petrol and diesel are reconciled independently", () => {
  const petrol = variance(1010, 10, 0);
  const diesel = variance(2025, 24, 1);
  assert.equal(petrol, 0);
  assert.equal(diesel, 0);
});

test("variance cannot be submitted until explained and approved", () => {
  const line = { status: "VARIANCE", varianceExplanation: "meter reading checked", varianceApprovedBy: "manager-1" };
  assert.equal(line.status === "VARIANCE" && !!line.varianceExplanation && !!line.varianceApprovedBy, true);
});

test("recalculated variance must require fresh approval", () => {
  const previousApproval = { varianceApprovedBy: "manager-1" };
  const recalculated = { status: "VARIANCE", varianceApprovedBy: null, varianceExplanation: null };
  assert.equal(previousApproval.varianceApprovedBy, "manager-1");
  assert.equal(recalculated.varianceApprovedBy, null);
  assert.equal(recalculated.varianceExplanation, null);
});
