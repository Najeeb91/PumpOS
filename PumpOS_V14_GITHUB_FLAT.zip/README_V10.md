# PumpOS V10 — Idempotency & Web Security

- Idempotency keys are bound to a request fingerprint. Reusing a key for different sale data is rejected rather than silently returning the old sale.
- Unique-key race handling remains in place for duplicate submissions.
- Standard browser security headers are configured at the Next.js layer.
- Production still requires HTTPS, secure environment secrets, database backups/restore drills and dependency scanning.
