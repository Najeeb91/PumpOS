# PumpOS Production Gate

## Database
- PostgreSQL with automated backups
- Real Prisma migration generated from the pinned schema/version
- `prisma migrate deploy` in CI/CD
- Restore drill completed
- Connection pooling configured

## Security
- HTTPS only
- Strong production secrets
- Session expiration and logout enabled
- Role + station authorization on every API
- Security headers enabled
- Rate limiting/WAF at deployment edge

## Financial integrity
- Decimal/paise-safe calculations
- Split payments balanced to sale total
- Price locked on sale
- Completed financial events immutable
- VOID/REVERSAL audited
- Credit limit enforced transactionally
- Cash reconciliation uses Payment rows
- Exact-zero fuel reconciliation
- Meter exceptions and non-sale dispensing explicitly approved

## Operational acceptance
- Test with 5–10 real stations
- Verify salesman sale entry in <10 seconds for normal flow
- Verify closing workflow on real nozzle/meter patterns
- Verify power/network interruption behavior
- Verify duplicate tap/retry behavior
- Verify manager approval and audit trail
