# PumpOS Deployment

## Required environment
`DATABASE_URL` must point to the production PostgreSQL database.

## First deployment
1. Generate the real initial Prisma migration with the exact pinned Prisma version.
2. Review the SQL.
3. Commit the migration under `prisma/migrations/`.
4. Run `npx prisma migrate deploy` during deployment.
5. Run `npx prisma db seed` only for a non-production/demo environment.
6. Start the application.
7. Check `/api/health`.

## Container
Build with Docker and run with `DATABASE_URL` supplied as a secret/environment variable.

## Before accepting real money
- Do not use demo credentials.
- Configure HTTPS.
- Put rate limiting/WAF at the edge.
- Configure PostgreSQL backups and perform a restore drill.
- Verify station/role isolation with an integration test.
- Run a real-station pilot before broad rollout.
