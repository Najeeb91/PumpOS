# PumpOS V7 — Control Integrity

V7 hardens the shift-closing path before production deployment.

## Locked flow
OPEN → CLOSING → reconcile fuel → reconcile cash → PENDING_APPROVAL → manager approval → CLOSED

Closing meter entry no longer moves a shift directly to PENDING_APPROVAL. The explicit submit endpoint does that only after all required controls pass.

## Important fixes
- Cash reconciliation is based on authoritative `Payment` rows, not `Sale.paymentMethod`, so split Cash + UPI/Card sales do not inflate expected cash.
- Reversed/voided payments no longer count toward expected cash.
- Every shift-closing endpoint checks station ownership and shift ownership/state.
- Exact-zero fuel reconciliation remains mandatory; no tolerance band.
- Money helper uses integer paise arithmetic instead of JavaScript floating point.
- Domain tests cover exact-zero and non-zero fuel variance.

## Production gate still required
1. Generate the real Prisma initial migration against the exact pinned Prisma version.
2. Apply it to disposable PostgreSQL and run `prisma migrate deploy`.
3. Run `npm test` and `npm run typecheck` with dependencies installed.
4. Add PostgreSQL integration tests for concurrent idempotency and credit-limit races.
5. Add explicit meter reset/rollover/replacement workflow before enabling those physical scenarios.
6. Configure production secrets, backups, restore drills, monitoring and rate limiting.
