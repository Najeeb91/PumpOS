import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth/session";

export default async function Salesman() {
  const user = await requireUser(["SALESMAN"]);
  const shift = user ? await prisma.shift.findFirst({
    where: { assignedUserId: user.id, status: { in: ["OPEN","CLOSING","PENDING_APPROVAL"] } },
    orderBy: { startedAt: "desc" },
    include: { sales: true, meterReadings: true }
  }) : null;

  return (
    <main className="shell">
      <div className="nav"><a href="/">Home</a><a href="/salesman">Salesman</a></div>
      <div className="card">
        <div className="muted">SALESMAN</div>
        <div className="title">{user?.name ?? "Demo Salesman"}</div>
        <p className="muted">{shift ? `Shift #${shift.shiftNumber} • ${shift.status}` : "No active shift"}</p>
      </div>
      {shift ? (
        <>
          <div className="grid">
            <div className="card"><div className="muted">SALES</div><div className="big money">₹{shift.sales.reduce((s,x)=>s+Number(x.grossAmount),0).toFixed(2)}</div></div>
            <div className="card"><div className="muted">TRANSACTIONS</div><div className="big">{shift.sales.length}</div></div>
          </div>
          <div className="card">
            <a className="btn" href={`/salesman/sale?shiftId=${shift.id}`}>+ NEW SALE</a>
          </div>
          <div className="card">
            <form action="/api/shifts" method="post">
              <input type="hidden" name="action" value="close" />
              <input type="hidden" name="shiftId" value={shift.id} />
              <button className="btn secondary">Begin Closing</button>
            </form>
          </div>
          <div className="card"><a className="btn" href="/salesman/closing">OPEN CLOSING CONTROL</a></div>
        </>
      ) : (
        <div className="card">
          <form action="/api/shifts" method="post">
            <input type="hidden" name="action" value="start" />
            <label className="label">Opening cash</label>
            <input className="input" name="openingCash" inputMode="decimal" defaultValue="0" />
            <button className="btn" style={{marginTop:12}}>START SHIFT</button>
          </form>
        </div>
      )}
    </main>
  );
}