"use client";
import {useEffect,useMemo,useState} from "react";

const DENOMS=[500,200,100,50,20,10,5,2,1];
export default function Closing(){
 const [shiftId,setShiftId]=useState(""); const [rows,setRows]=useState<any[]>([]); const [counts,setCounts]=useState<Record<number,number>>({}); const [loading,setLoading]=useState(true); const [saving,setSaving]=useState(false); const [message,setMessage]=useState(""); const [explanation,setExplanation]=useState(""); const [variances,setVariances]=useState<any[]>([]);
 useEffect(()=>{fetch('/api/shifts/current').then(r=>r.json()).then(d=>{setShiftId(d.shift?.id||"");setRows(d.nozzles||[]);}).finally(()=>setLoading(false))},[]);
 const actual=useMemo(()=>DENOMS.reduce((s,d)=>s+d*(counts[d]||0),0),[counts]);
 async function submitMeters(){
  setSaving(true); setMessage("");
  const readings=rows.map(r=>({nozzleId:r.nozzleId,meterValue:r.closing||""}));
  const r=await fetch(`/api/shifts/${shiftId}/close`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({readings})});
  const d=await r.json(); if(!r.ok){setMessage(d.error||'Could not save');setSaving(false);return;}
  const rr=await fetch(`/api/shifts/${shiftId}/reconcile`,{method:'POST'}); const rd=await rr.json();
  const cr=await fetch(`/api/shifts/${shiftId}/cash`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({actualCash:actual,explanation})}); const cd=await cr.json();
  if(!rr.ok || !cr.ok){setMessage(rd.error||cd.error||'Closing control failed');setSaving(false);return;}
  const found=(rd.results||[]).filter((x:any)=>x.status==='VARIANCE');
  if(found.length){setVariances(found);setMessage('Fuel variance found. Explain each variance below; manager approval is required.');setSaving(false);return;}
  const sr=await fetch(`/api/shifts/${shiftId}/submit`,{method:'POST'}); const sd=await sr.json();
  if(!sr.ok){setMessage(sd.error||'Could not submit shift');setSaving(false);return;}
  setMessage('Closing submitted for manager approval.'); setSaving(false);
 }
 if(loading)return <main className="shell"><div className="card">Loading…</div></main>;
 if(!shiftId)return <main className="shell"><div className="card"><div className="title">No active shift</div><a className="btn" href="/salesman">Back</a></div></main>;
 return <main className="shell"><div className="nav"><a href="/salesman">Salesman</a><a href="/manager">Manager</a></div><div className="card"><div className="muted">SHIFT CLOSING</div><div className="title">Closing Meter</div>{rows.map((r,i)=><div className="card" key={r.nozzleId}><div className="between row"><b>Nozzle {r.nozzleNumber}</b><span className="pill">{r.fuel}</span></div><div className="muted">Opening: {r.opening}</div><label className="label">Closing meter</label><input className="input" inputMode="decimal" value={r.closing||''} onChange={e=>setRows(x=>x.map((a,j)=>j===i?{...a,closing:e.target.value}:a))}/></div>)} </div>
 <div className="card"><div className="title">Cash Count</div><div className="grid">{DENOMS.map(d=><div key={d}><label className="label">₹{d} notes</label><input className="input" inputMode="numeric" value={counts[d]||''} onChange={e=>setCounts(x=>({...x,[d]:Number(e.target.value)||0}))}/></div>)}</div><p><b>Actual cash: ₹{actual.toFixed(2)}</b></p><label className="label">Explanation (required if difference)</label><textarea className="input" rows={3} value={explanation} onChange={e=>setExplanation(e.target.value)} /></div>
 {variances.length>0&&<div className="card"><div className="title">Explain Fuel Variance</div>{variances.map((v:any)=><div className="card" key={v.lineId}><div className="muted">Nozzle {rows.find(r=>r.nozzleId===v.nozzleId)?.nozzleNumber||''} • Variance {v.varianceLitres} L</div><input className="input" placeholder="Explain the reason" value={v.explanation||''} onChange={e=>setVariances(x=>x.map(a=>a.lineId===v.lineId?{...a,explanation:e.target.value}:a))}/><button className="btn secondary" style={{marginTop:8}} onClick={async()=>{const r=await fetch(`/api/shifts/${shiftId}/variance`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({lineId:v.lineId,explanation:v.explanation})});const d=await r.json();setMessage(r.ok?'Explanation saved. Manager can now approve it.':(d.error||'Could not save explanation'));}}>SAVE EXPLANATION</button></div>)}</div>}
 <button className="btn" disabled={saving} onClick={submitMeters}>{saving?'SUBMITTING…':'SUBMIT FOR MANAGER APPROVAL'}</button>{message&&<div className="card"><b>{message}</b></div>}</main>
}
