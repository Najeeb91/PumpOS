import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth/session";

export default async function SalePage({ searchParams }: { searchParams: Promise<{shiftId?: string}> }) {
  const { shiftId } = await searchParams;
  const user = await requireUser(["SALESMAN"]);
  const shift = shiftId ? await prisma.shift.findFirst({ where: { id: shiftId, stationId:user.stationId, assignedUserId:user.id, status:"OPEN" } }) : null;
  const nozzles = shift ? await prisma.nozzle.findMany({ where: { isActive: true, machine:{stationId:user.stationId,isActive:true} }, include: { fuelProduct: true, machine: true } }) : [];
  const customers = await prisma.customer.findMany({where:{stationId:user.stationId,isActive:true},orderBy:{name:"asc"}});
  return (
    <main className="shell">
      <div className="nav"><a href="/salesman">← Shift</a></div>
      <div className="card">
        <div className="title">New Sale</div>
        <p className="muted">Amount OR litres. Rate is system-controlled. Split payments are supported.</p>
        <form action="/api/sales" method="post">
          <input type="hidden" name="shiftId" value={shiftId ?? ""} />
          <input type="hidden" name="idempotencyKey" value={crypto.randomUUID()} />
          <label className="label">Nozzle</label>
          <select className="input" name="nozzleId">{nozzles.map(n=><option key={n.id} value={n.id}>{n.machine.name} • N{n.nozzleNumber} • {n.fuelProduct.name}</option>)}</select>
          <label className="label">Amount (optional)</label><input className="input" name="amount" inputMode="decimal" placeholder="₹ 1000" />
          <label className="label">OR Litres (optional)</label><input className="input" name="quantityLitres" inputMode="decimal" placeholder="10.582" />
          <label className="label">Payment</label>
          <select className="input" name="paymentMethod" defaultValue="CASH">
            <option value="CASH">Cash</option><option value="UPI">UPI</option><option value="CARD">Card</option><option value="BANK_TRANSFER">Bank Transfer</option><option value="CREDIT">Credit</option>
          </select>
          <label className="label">Credit customer (only for Credit)</label>
          <select className="input" name="customerId" defaultValue=""><option value="">— Select customer —</option>{customers.map(c=><option key={c.id} value={c.id}>{c.name} • Outstanding ₹{c.currentBalance.toFixed(2)} / Limit ₹{c.creditLimit.toFixed(2)}</option>)}</select>
          <label className="label">Payment reference / UTR (optional)</label><input className="input" name="reference" placeholder="Optional UTR / reference" />
          <label className="label">Split payments (optional JSON)</label><input className="input" name="payments" placeholder='[{"method":"CASH","amount":"500"},{"method":"UPI","amount":"500"}]' />
          <button className="btn" style={{marginTop:14}}>COMPLETE SALE</button>
        </form>
      </div>
    </main>
  );
}
