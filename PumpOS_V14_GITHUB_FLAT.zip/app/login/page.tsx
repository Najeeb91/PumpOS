import { getCurrentUser } from "@/lib/auth/session";
import { redirect } from "next/navigation";

export default async function Login({ searchParams }: { searchParams: Promise<{error?:string}> }) {
  const user = await getCurrentUser(); if (user) redirect(user.role === "SALESMAN" ? "/salesman" : user.role === "MANAGER" ? "/manager" : "/owner");
  const params = await searchParams;
  return <main className="shell"><div className="card"><div className="title">PumpOS</div><p className="muted">Secure station login</p>{params.error && <p className="error">Invalid phone or password.</p>}<form action="/api/auth/login" method="post"><label>Mobile number<input name="phone" inputMode="numeric" maxLength={10} required /></label><label>Password<input name="password" type="password" required /></label><button className="btn" type="submit">Login</button></form><p className="muted small">Demo passwords are now real password hashes; set them during seed.</p></div></main>;
}
