import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/prisma";

export default async function Owner() {
  const user = await requireUser(["OWNER"]);
  const shifts = await prisma.shift.findMany({ where:{stationId:user.stationId}, orderBy:{startedAt:"desc"}, take:10, include:{assignedUser:true} });
  const sales = await prisma.sale.aggregate({ where:{stationId:user.stationId,status:"COMPLETED"}, _sum:{grossAmount:true} });
  return <main className="shell"><div className="card"><div className="title">Owner Control</div><p>Welcome, {user.name}</p><div className="grid"><div className="card"><div className="muted">Grand Total Value</div><div className="big">₹{sales._sum.grossAmount?.toString() ?? "0.00"}</div></div><div className="card"><div className="muted">Recent Shifts</div><div className="big">{shifts.length}</div></div></div><h3>Recent shifts</h3>{shifts.map(s=><div className="row" key={s.id}><span>#{s.shiftNumber} · {s.assignedUser.name}</span><span>{s.status}</span></div>)}<form action="/api/auth/logout" method="post"><button className="btn secondary">Logout</button></form></div></main>;
}
