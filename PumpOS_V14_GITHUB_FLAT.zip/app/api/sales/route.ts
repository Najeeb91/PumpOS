import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import { requireUser } from "@/lib/auth/session";
import crypto from "crypto";

function dec(v:string){ return new Prisma.Decimal(v); }
function fail(message:string,status=400){ return NextResponse.json({error:message},{status}); }

export async function POST(req: NextRequest) {
  let user;
  try { user = await requireUser(["SALESMAN"]); }
  catch (e:any) { return fail(e.message,e.message==="FORBIDDEN"?403:401); }

  const form = await req.formData();
  const shiftId = String(form.get("shiftId") || "");
  const nozzleId = String(form.get("nozzleId") || "");
  const amountRaw = String(form.get("amount") || "").trim();
  const qtyRaw = String(form.get("quantityLitres") || "").trim();
  const paymentMethod = String(form.get("paymentMethod") || "CASH") as any;
  const customerId = String(form.get("customerId") || "").trim() || null;
  const reference = String(form.get("reference") || "").trim() || null;
  const paymentsRaw = String(form.get("payments") || "").trim();
  const idempotencyKey = String(form.get("idempotencyKey") || crypto.randomUUID()).trim();
  const requestHash = crypto.createHash("sha256").update(JSON.stringify({shiftId,nozzleId,amountRaw,qtyRaw,paymentMethod,customerId,reference,paymentsRaw})).digest("hex");

  const allowed = ["CASH","UPI","CARD","BANK_TRANSFER","CREDIT"];
  if (!allowed.includes(paymentMethod)) return fail("Invalid payment method");
  if (!shiftId || !nozzleId) return fail("Shift and nozzle are required");

  try {
    const result = await prisma.$transaction(async tx => {
      const existing = await tx.sale.findUnique({where:{idempotencyKey},select:{referenceNumber:true,idempotencyHash:true}});
      if (existing) {
        if (existing.idempotencyHash !== requestHash) throw new Error("Idempotency key was already used for a different sale");
        return {referenceNumber:existing.referenceNumber, duplicate:true};
      }

      const shift = await tx.shift.findFirst({where:{id:shiftId,stationId:user.stationId,assignedUserId:user.id,status:"OPEN"}});
      if (!shift) throw new Error("Shift is not open");

      const nozzle = await tx.nozzle.findUnique({where:{id:nozzleId},include:{fuelProduct:true,machine:true}});
      if (!nozzle || !nozzle.isActive || nozzle.machine.stationId !== user.stationId) throw new Error("Invalid nozzle");

      const now = new Date();
      const price = await tx.fuelPrice.findFirst({
        where:{stationId:user.stationId,fuelProductId:nozzle.fuelProductId,effectiveFrom:{lte:now},OR:[{effectiveTo:null},{effectiveTo:{gt:now}}]},
        orderBy:{effectiveFrom:"desc"}
      });
      if (!price) throw new Error("No active fuel price");

      let quantity: Prisma.Decimal;
      let gross: Prisma.Decimal;
      if (amountRaw && qtyRaw) {
        const enteredAmount = dec(amountRaw).toDecimalPlaces(2);
        const enteredQty = dec(qtyRaw).toDecimalPlaces(3);
        if (enteredAmount.lte(0) || enteredQty.lte(0)) throw new Error("Amount and litres must be positive");
        const calculated = enteredQty.mul(price.pricePerLitre).toDecimalPlaces(2);
        if (!calculated.eq(enteredAmount)) throw new Error(`Amount does not match litres at ₹${price.pricePerLitre.toFixed(2)}`);
        gross = enteredAmount; quantity = enteredQty;
      } else if (amountRaw) {
        gross = dec(amountRaw).toDecimalPlaces(2);
        if (gross.lte(0)) throw new Error("Amount must be positive");
        quantity = gross.div(price.pricePerLitre).toDecimalPlaces(3);
      } else if (qtyRaw) {
        quantity = dec(qtyRaw).toDecimalPlaces(3);
        if (quantity.lte(0)) throw new Error("Litres must be positive");
        gross = quantity.mul(price.pricePerLitre).toDecimalPlaces(2);
      } else throw new Error("Enter amount or litres");

      if (paymentMethod === "CREDIT") {
        if (!customerId) throw new Error("Customer is required for credit sale");
        const customer = await tx.customer.findFirst({where:{id:customerId,stationId:user.stationId,isActive:true}});
        if (!customer) throw new Error("Invalid customer");
        const available = customer.creditLimit.sub(customer.currentBalance);
        if (gross.gt(available)) throw new Error(`Credit limit exceeded. Available ₹${available.toFixed(2)}`);
      } else if (customerId) {
        throw new Error("Customer is only required for credit sales");
      }

      let paymentLines: {method:any,amount:Prisma.Decimal,reference?:string|null}[];
      if (paymentsRaw) {
        let parsed:any;
        try { parsed = JSON.parse(paymentsRaw); } catch { throw new Error("Invalid payment split"); }
        if (!Array.isArray(parsed) || parsed.length < 1) throw new Error("Invalid payment split");
        paymentLines = parsed.map((x:any)=>({method:String(x.method),amount:dec(String(x.amount)).toDecimalPlaces(2),reference:String(x.reference||"").trim()||null}));
      } else {
        paymentLines = [{method:paymentMethod,amount:gross,reference}];
      }
      if (paymentLines.some(p=>!allowed.includes(p.method) || p.amount.lte(0))) throw new Error("Invalid payment line");
      const totalPaid = paymentLines.reduce((a,p)=>a.add(p.amount),new Prisma.Decimal(0)).toDecimalPlaces(2);
      if (!totalPaid.eq(gross)) throw new Error(`Payment total must equal ₹${gross.toFixed(2)}`);
      const hasCredit = paymentLines.some(p=>p.method==="CREDIT");
      if (hasCredit && paymentLines.length > 1) throw new Error("Credit cannot be split with other payment methods in MVP");
      if (hasCredit && !customerId) throw new Error("Customer is required for credit sale");
      if (!hasCredit && customerId) throw new Error("Customer is only required for credit sales");
      if (paymentMethod === "CREDIT" && !hasCredit) throw new Error("Credit payment mismatch");

      const referenceNumber = `P${Date.now()}-${Math.floor(Math.random()*10000).toString().padStart(4,"0")}`;
      const sale = await tx.sale.create({data:{stationId:user.stationId,shiftId,userId:user.id,nozzleId,fuelProductId:nozzle.fuelProductId,customerId,quantityLitres:quantity,unitPrice:price.pricePerLitre,grossAmount:gross,paymentMethod:paymentLines.length===1?paymentLines[0].method:"CASH",status:"COMPLETED",referenceNumber,idempotencyKey,idempotencyHash:requestHash}});
      await tx.payment.createMany({data:paymentLines.map(p=>({saleId:sale.id,method:p.method,amount:p.amount,reference:p.reference}))});

      if (hasCredit) {
        const updated = await tx.$executeRaw`
          UPDATE "Customer"
          SET "currentBalance" = "currentBalance" + ${gross}
          WHERE "id" = ${customerId!}
            AND "stationId" = ${user.stationId}
            AND "isActive" = true
            AND "currentBalance" + ${gross} <= "creditLimit"
        `;
        if (updated !== 1) throw new Error("Credit limit exceeded or customer unavailable");
        const fresh = await tx.customer.findUnique({where:{id:customerId!}});
        if (!fresh || fresh.currentBalance.gt(fresh.creditLimit)) throw new Error("Credit limit exceeded");
        await tx.creditLedger.create({data:{customerId:customerId!,saleId:sale.id,type:"CREDIT_SALE",amount:gross,balanceAfter:fresh.currentBalance,reference:referenceNumber,createdBy:user.id}});
      }
      await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:"SALE_COMPLETED",entityType:"Sale",entityId:sale.id,newValue:{quantityLitres:quantity.toString(),unitPrice:price.pricePerLitre.toString(),grossAmount:gross.toString(),payments:paymentLines.map(p=>({method:p.method,amount:p.amount.toString()})),customerId}}});
      return {referenceNumber:sale.referenceNumber,duplicate:false};
    });
    return NextResponse.redirect(new URL(`/salesman?success=${result.referenceNumber}${result.duplicate?"&duplicate=1":""}`, req.url));
  } catch(e:any) {
    if(e?.code === "P2002" && String(e?.meta?.target || "").includes("idempotencyKey")){
      const key = String(form.get("idempotencyKey") || "");
      if(key){ const existing = await prisma.sale.findUnique({where:{idempotencyKey:key},select:{referenceNumber:true,idempotencyHash:true}}); if(existing){ if(existing.idempotencyHash !== requestHash) return fail("Idempotency key was already used for a different sale",409); return NextResponse.redirect(new URL(`/salesman?success=${existing.referenceNumber}&duplicate=1`, req.url)); }
      }
    }
    return fail(e.message || "Sale failed");
  }
}
