import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth/session";

export async function GET(){
  let user;
  try { user=await requireUser(["SALESMAN","MANAGER","OWNER"]); }
  catch(e:any){ return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401}); }
  const sales=await prisma.sale.findMany({where:{stationId:user.stationId},orderBy:{transactionTime:"desc"},take:100,include:{nozzle:true,fuelProduct:true,user:true,payments:true,customer:true,corrections:true}});
  return NextResponse.json(sales.map(s=>({
    id:s.id, referenceNumber:s.referenceNumber, time:s.transactionTime, status:s.status,
    quantityLitres:s.quantityLitres.toString(), unitPrice:s.unitPrice.toString(), grossAmount:s.grossAmount.toString(),
    paymentMethod:s.paymentMethod, nozzle:s.nozzle.nozzleNumber, fuel:s.fuelProduct.name, salesman:s.user.name,
    customer:s.customer?.name||null,
    payments:s.payments.map(p=>({method:p.method,amount:p.amount.toString(),reference:p.reference,status:p.status})),
    corrections:s.corrections.map(c=>({type:c.type,reason:c.reason,deltaLitres:c.deltaLitres?.toString()||null,deltaAmount:c.deltaAmount?.toString()||null,createdAt:c.createdAt}))
  })));
}
