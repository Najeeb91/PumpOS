import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth/session";

const dec = (v:string) => new Prisma.Decimal(v);
const fail = (m:string,s=400) => NextResponse.json({error:m},{status:s});

export async function POST(req: NextRequest, {params}:{params:Promise<{id:string}>}) {
  let user;
  try { user = await requireUser(["MANAGER","OWNER"]); } catch(e:any) { return fail(e.message,e.message==="FORBIDDEN"?403:401); }
  const {id} = await params;
  const form = await req.formData();
  const type = String(form.get("type")||"").toUpperCase();
  const reason = String(form.get("reason")||"").trim();
  const deltaLitresRaw = String(form.get("deltaLitres")||"").trim();
  const deltaAmountRaw = String(form.get("deltaAmount")||"").trim();
  if (!["VOID","REVERSAL","ADJUSTMENT"].includes(type)) return fail("Invalid correction type");
  if (!reason) return fail("Reason is required");
  try {
    const result = await prisma.$transaction(async tx => {
      const sale = await tx.sale.findFirst({where:{id,stationId:user.stationId},include:{payments:true,customer:true}});
      if (!sale) throw new Error("Sale not found");
      if (sale.status !== "COMPLETED") throw new Error("Only completed sales can be corrected");
      if (type === "ADJUSTMENT") {
        throw new Error("ADJUSTMENT is temporarily disabled: use VOID/REVERSAL until a balanced financial adjustment model is enabled");
        if (!deltaLitresRaw || !deltaAmountRaw) throw new Error("Adjustment requires litres and amount");
        const dl = dec(deltaLitresRaw).toDecimalPlaces(3), da = dec(deltaAmountRaw).toDecimalPlaces(2);
        if (dl.eq(0) || da.eq(0)) throw new Error("Adjustment cannot be zero");
        const newQty = sale.quantityLitres.add(dl);
        const newAmount = sale.grossAmount.add(da);
        if (newQty.lte(0) || newAmount.lte(0)) throw new Error("Adjustment would make sale invalid");
        await tx.saleCorrection.create({data:{stationId:user.stationId,saleId:sale.id,type,reason,deltaLitres:dl,deltaAmount:da,createdBy:user.id,approvedBy:user.id,approvedAt:new Date()}});
        await tx.sale.update({where:{id:sale.id},data:{quantityLitres:newQty,grossAmount:newAmount}});
        await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:"SALE_ADJUSTED",entityType:"Sale",entityId:sale.id,oldValue:{quantityLitres:sale.quantityLitres.toString(),grossAmount:sale.grossAmount.toString()},newValue:{quantityLitres:newQty.toString(),grossAmount:newAmount.toString(),reason}}});
        return {type};
      }
      await tx.saleCorrection.create({data:{stationId:user.stationId,saleId:sale.id,type,reason,createdBy:user.id,approvedBy:user.id,approvedAt:new Date()}});
      const status = type === "VOID" ? "VOIDED" : "REVERSED";
      await tx.sale.update({where:{id:sale.id},data:{status}});
      await tx.payment.updateMany({where:{saleId:sale.id,status:"COMPLETED"},data:{status:type === "VOID" ? "VOIDED" : "REVERSED"}});
      if (sale.customerId && sale.paymentMethod === "CREDIT") {
        const updated = await tx.$executeRaw`UPDATE "Customer" SET "currentBalance" = "currentBalance" - ${sale.grossAmount} WHERE "id"=${sale.customerId} AND "stationId"=${user.stationId} AND "currentBalance" >= ${sale.grossAmount}`;
        if (updated !== 1) throw new Error("Credit balance reversal failed");
        const fresh = await tx.customer.findUnique({where:{id:sale.customerId}});
        if (!fresh) throw new Error("Customer not found");
        await tx.creditLedger.create({data:{customerId:sale.customerId,saleId:sale.id,type:"REVERSAL",amount:sale.grossAmount.neg(),balanceAfter:fresh.currentBalance,reference:sale.referenceNumber,createdBy:user.id}});
      }
      await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:`SALE_${status}`,entityType:"Sale",entityId:sale.id,newValue:{reason}}});
      return {type};
    });
    return NextResponse.json({ok:true,...result});
  } catch(e:any) { return fail(e.message||"Correction failed"); }
}
