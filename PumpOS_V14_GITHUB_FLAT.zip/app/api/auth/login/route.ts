import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession, verifyPassword } from "@/lib/auth/session";

export async function POST(req: NextRequest) {
  const form = await req.formData();
  const phone = String(form.get("phone") || "").trim();
  const password = String(form.get("password") || "");
  if (!/^\d{10}$/.test(phone) || !password) return NextResponse.redirect(new URL("/login?error=invalid", req.url));
  const user = await prisma.user.findFirst({ where: { phone, isActive: true, station: { isActive: true } } });
  if (!user || !verifyPassword(password, user.passwordHash)) return NextResponse.redirect(new URL("/login?error=invalid", req.url));
  await createSession(user.id);
  await prisma.auditLog.create({ data: { stationId: user.stationId, userId: user.id, action: "LOGIN", entityType: "User", entityId: user.id } });
  const destination = user.role === "SALESMAN" ? "/salesman" : user.role === "MANAGER" ? "/manager" : "/owner";
  return NextResponse.redirect(new URL(destination, req.url));
}
