import {NextResponse} from 'next/server';
import {prisma} from '@/lib/prisma';
import {requireUser} from '@/lib/auth/session';
export async function POST(_req:Request,{params}:{params:Promise<{id:string}>}){
 const {id}=await params; let user; try{user=await requireUser(['MANAGER','OWNER'])}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==='FORBIDDEN'?403:401});}
 const ex=await prisma.meterException.findFirst({where:{id,shift:{stationId:user.stationId}}}); if(!ex)return NextResponse.json({error:'Exception not found'},{status:404});
 if(ex.status!=='OPEN')return NextResponse.json({error:'Exception is not open'},{status:400});
 await prisma.$transaction(async tx=>{await tx.meterException.update({where:{id},data:{status:'APPROVED',approvedBy:user.id,approvedAt:new Date()}}); await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:'METER_EXCEPTION_APPROVED',entityType:'MeterException',entityId:id,newValue:{status:'APPROVED'}}});});
 return NextResponse.json({ok:true});
}
