import {NextRequest,NextResponse} from 'next/server';
import {prisma} from '@/lib/prisma';
import {Prisma} from '@prisma/client';
import {requireUser} from '@/lib/auth/session';
export async function POST(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 const {id}=await params; let user; try{user=await requireUser(['SALESMAN'])}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==='FORBIDDEN'?403:401});}
 const b=await req.json(); const nozzleId=String(b.nozzleId||''); const type=String(b.type||'').toUpperCase(); const reason=String(b.reason||'').trim(); const adjustedRaw=String(b.adjustedVolumeLitres||'').trim();
 if(!['ROLLOVER','RESET','REPLACEMENT'].includes(type)||!nozzleId||!reason||!adjustedRaw)return NextResponse.json({error:'Type, nozzle, reason and adjusted volume are required'},{status:400});
 const adjusted=new Prisma.Decimal(adjustedRaw).toDecimalPlaces(3); if(adjusted.lt(0))return NextResponse.json({error:'Adjusted volume cannot be negative'},{status:400});
 const shift=await prisma.shift.findFirst({where:{id,stationId:user.stationId,assignedUserId:user.id,status:'CLOSING'}}); if(!shift)return NextResponse.json({error:'Shift not in CLOSING state'},{status:400});
 const nozzle=await prisma.nozzle.findFirst({where:{id:nozzleId,isActive:true,machine:{stationId:user.stationId}}}); if(!nozzle)return NextResponse.json({error:'Invalid nozzle'},{status:400});
 const ex=await prisma.meterException.create({data:{shiftId:id,nozzleId,type:type as any,reason,adjustedVolumeLitres:adjusted,createdBy:user.id}});
 await prisma.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:'METER_EXCEPTION_CREATED',entityType:'MeterException',entityId:ex.id,newValue:{type,reason,adjustedVolumeLitres:adjusted.toFixed(3)}}});
 return NextResponse.json({ok:true,id:ex.id,status:ex.status});
}
