import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import { requireUser } from "@/lib/auth/session";

export async function POST(req: NextRequest, {params}:{params:Promise<{id:string}>}) {
  const {id} = await params;
  const body = await req.json();
  let user; try { user = await requireUser(["SALESMAN"]); } catch (e:any) { return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401}); }
  const shift = await prisma.shift.findFirst({where:{id,assignedUserId:user.id,status:"CLOSING"}});
  if (!shift) return NextResponse.json({error:"Shift not in CLOSING state"},{status:400});
  if (shift.stationId !== user.stationId) return NextResponse.json({error:"Forbidden"},{status:403});

  const nozzles = await prisma.nozzle.findMany({where:{isActive:true,machine:{stationId:user.stationId}}});
  const readings = body.readings as {nozzleId:string,meterValue:string}[];
  if (!Array.isArray(readings) || readings.length !== nozzles.length) return NextResponse.json({error:"Closing meter required for every active nozzle"},{status:400});

  await prisma.$transaction(async tx=>{
    for (const n of nozzles) {
      const r = readings.find(x=>x.nozzleId===n.id);
      if (!r) throw new Error(`Missing nozzle ${n.id}`);
      const opening = await tx.meterReading.findUnique({where:{shiftId_nozzleId_readingType:{shiftId:id,nozzleId:n.id,readingType:"OPENING"} }});
      const exception = await tx.meterException.findFirst({where:{shiftId:id,nozzleId:n.id,status:"APPROVED"},orderBy:{createdAt:"desc"}});
      const value = new Prisma.Decimal(r.meterValue);
      if (!opening) throw new Error("Opening meter missing");
      if (value.lt(opening.meterValue) && !exception) throw new Error("Closing meter cannot be below opening without an approved meter exception");
      await tx.meterReading.upsert({where:{shiftId_nozzleId_readingType:{shiftId:id,nozzleId:n.id,readingType:"CLOSING"}},update:{meterValue:value,recordedBy:user.id,recordedAt:new Date()},create:{shiftId:id,nozzleId:n.id,readingType:"CLOSING",meterValue:value,recordedBy:user.id}});
    }
  });

  return NextResponse.json({ok:true});
}