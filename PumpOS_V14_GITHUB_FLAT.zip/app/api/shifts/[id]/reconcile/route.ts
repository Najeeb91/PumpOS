import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import { requireUser } from "@/lib/auth/session";

export async function POST(_req: NextRequest, {params}:{params:Promise<{id:string}>}) {
 const {id}=await params; let user; try{user=await requireUser(["SALESMAN","MANAGER","OWNER"])}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401});}
 const shift=await prisma.shift.findFirst({where:{id,stationId:user.stationId}}); if(!shift)return NextResponse.json({error:"Shift not found"},{status:404});
 const nozzles=await prisma.nozzle.findMany({where:{isActive:true,machine:{stationId:shift.stationId}}}); const results:any[]=[];
 await prisma.$transaction(async tx=>{
  for(const n of nozzles){
   const [o,c,ex]=await Promise.all([
    tx.meterReading.findUnique({where:{shiftId_nozzleId_readingType:{shiftId:id,nozzleId:n.id,readingType:"OPENING"}}}),
    tx.meterReading.findUnique({where:{shiftId_nozzleId_readingType:{shiftId:id,nozzleId:n.id,readingType:"CLOSING"}}}),
    tx.meterException.findFirst({where:{shiftId:id,nozzleId:n.id,status:"APPROVED"},orderBy:{createdAt:"desc"}})
   ]);
   if(!o||!c){results.push({nozzleId:n.id,status:"INVALID"});continue;}
   const rawMeterVolume=c.meterValue.sub(o.meterValue);
   const meterVolume=ex?.adjustedVolumeLitres ? ex.adjustedVolumeLitres : rawMeterVolume;
   if(meterVolume.lt(0)){results.push({nozzleId:n.id,status:"INVALID",reason:"Closing meter below opening without approved exception"});continue;}
   const sales=(await tx.sale.aggregate({where:{shiftId:id,nozzleId:n.id,status:"COMPLETED"},_sum:{quantityLitres:true}}))._sum.quantityLitres??new Prisma.Decimal(0);
   const nonSale=(await tx.nonSaleDispensing.aggregate({where:{shiftId:id,nozzleId:n.id,status:"APPROVED"},_sum:{quantityLitres:true}}))._sum.quantityLitres??new Prisma.Decimal(0);
   const variance=meterVolume.sub(sales).sub(nonSale); const status=variance.eq(0)?"RECONCILED":"VARIANCE";
   const line=await tx.reconciliationLine.upsert({where:{shiftId_nozzleId:{shiftId:id,nozzleId:n.id}},update:{openingMeter:o.meterValue,closingMeter:c.meterValue,meterVolume,salesVolume:sales,nonSaleVolume:nonSale,varianceLitres:variance,status,varianceExplanation:null,varianceExplainedBy:null,varianceExplainedAt:null,varianceApprovedBy:null,varianceApprovedAt:null},create:{shiftId:id,nozzleId:n.id,openingMeter:o.meterValue,closingMeter:c.meterValue,meterVolume,salesVolume:sales,nonSaleVolume:nonSale,varianceLitres:variance,status}});
   results.push({nozzleId:n.id,status,varianceLitres:variance.toFixed(3),lineId:line.id,meterExceptionId:ex?.id??null});
  }
 });
 return NextResponse.json({shiftId:id,results});
}
