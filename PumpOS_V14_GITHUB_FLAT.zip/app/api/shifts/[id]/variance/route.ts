import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth/session";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let user;
  try { user = await requireUser(["SALESMAN"]); }
  catch (e: any) { return NextResponse.json({ error: e.message }, { status: e.message === "FORBIDDEN" ? 403 : 401 }); }
  const body = await req.json().catch(() => ({}));
  const lineId = String(body.lineId || "");
  const explanation = String(body.explanation || "").trim();
  if (!lineId || !explanation) return NextResponse.json({ error: "Variance line and explanation are required" }, { status: 400 });
  const line = await prisma.reconciliationLine.findFirst({ where: { id: lineId, shiftId: id, shift: { stationId: user.stationId, assignedUserId: user.id, status: "CLOSING" } } });
  if (!line) return NextResponse.json({ error: "Variance line not found" }, { status: 404 });
  if (line.status !== "VARIANCE") return NextResponse.json({ error: "Explanation is only required for a variance" }, { status: 400 });
  await prisma.$transaction(async tx => {
    await tx.reconciliationLine.update({ where: { id: line.id }, data: { varianceExplanation: explanation, varianceExplainedBy: user.id, varianceExplainedAt: new Date(), varianceApprovedBy: null, varianceApprovedAt: null } });
    await tx.auditLog.create({ data: { stationId: user.stationId, userId: user.id, action: "FUEL_VARIANCE_EXPLAINED", entityType: "ReconciliationLine", entityId: line.id, newValue: { explanation } } });
  });
  return NextResponse.json({ ok: true });
}
