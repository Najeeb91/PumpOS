import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth/session";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let user;
  try { user = await requireUser(["MANAGER", "OWNER"]); }
  catch (e: any) { return NextResponse.json({ error: e.message }, { status: e.message === "FORBIDDEN" ? 403 : 401 }); }
  const body = await req.formData().catch(() => new FormData());
  const lineId = String(body.get("lineId") || "");
  const line = await prisma.reconciliationLine.findFirst({ where: { id: lineId, shiftId: id, shift: { stationId: user.stationId } } });
  if (!line) return NextResponse.json({ error: "Variance line not found" }, { status: 404 });
  if (line.status !== "VARIANCE" || !line.varianceExplanation) return NextResponse.json({ error: "Variance must be explained before approval" }, { status: 400 });
  await prisma.$transaction(async tx => {
    await tx.reconciliationLine.update({ where: { id: line.id }, data: { varianceApprovedBy: user.id, varianceApprovedAt: new Date() } });
    await tx.auditLog.create({ data: { stationId: user.stationId, userId: user.id, action: "FUEL_VARIANCE_APPROVED", entityType: "ReconciliationLine", entityId: line.id, newValue: { status: "APPROVED" } } });
  });
  return NextResponse.redirect(new URL("/manager", req.url));
}
