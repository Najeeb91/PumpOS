import {NextResponse} from 'next/server';
import {prisma} from '@/lib/prisma';
import {requireUser} from '@/lib/auth/session';
export async function POST(_req:Request,{params}:{params:Promise<{id:string}>}){
 const {id:shiftId}=await params; let user; try{user=await requireUser(['MANAGER','OWNER'])}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==='FORBIDDEN'?403:401});}
 const ct=_req.headers.get('content-type')||''; const body=ct.includes('application/json')?await _req.json().catch(()=>({})):Object.fromEntries((await _req.formData()).entries()); const id=String(body.id||''); const item=await prisma.nonSaleDispensing.findFirst({where:{id,shiftId,stationId:user.stationId}}); if(!item)return NextResponse.json({error:'Non-sale record not found'},{status:404});
 if(item.status!=='OPEN')return NextResponse.json({error:'Record is not open'},{status:400});
 await prisma.$transaction(async tx=>{await tx.nonSaleDispensing.update({where:{id},data:{status:'APPROVED',approvedBy:user.id,approvedAt:new Date()}}); await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:'NON_SALE_APPROVED',entityType:'NonSaleDispensing',entityId:item.id,newValue:{status:'APPROVED'}}});});
 return NextResponse.json({ok:true});
}
