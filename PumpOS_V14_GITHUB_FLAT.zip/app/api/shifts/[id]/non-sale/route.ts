import {NextRequest,NextResponse} from 'next/server';
import {prisma} from '@/lib/prisma';
import {Prisma} from '@prisma/client';
import {requireUser} from '@/lib/auth/session';
export async function POST(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 const {id}=await params; let user; try{user=await requireUser(['SALESMAN'])}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==='FORBIDDEN'?403:401});}
 const b=await req.json(); const nozzleId=String(b.nozzleId||''); const type=String(b.type||'').toUpperCase(); const reason=String(b.reason||'').trim(); const qty=new Prisma.Decimal(String(b.quantityLitres||'0')).toDecimalPlaces(3);
 if(!['TEST_POUR','CALIBRATION','MAINTENANCE','SAMPLE','OTHER'].includes(type)||!nozzleId||qty.lte(0)||!reason)return NextResponse.json({error:'Nozzle, type, positive litres and reason are required'},{status:400});
 const shift=await prisma.shift.findFirst({where:{id,stationId:user.stationId,assignedUserId:user.id,status:'CLOSING'}}); if(!shift)return NextResponse.json({error:'Shift not in CLOSING state'},{status:400});
 const nozzle=await prisma.nozzle.findFirst({where:{id:nozzleId,isActive:true,machine:{stationId:user.stationId}}}); if(!nozzle)return NextResponse.json({error:'Invalid nozzle'},{status:400});
 const item=await prisma.nonSaleDispensing.create({data:{stationId:user.stationId,shiftId:id,nozzleId,fuelProductId:nozzle.fuelProductId,quantityLitres:qty,type:type as any,reason,createdBy:user.id}});
 await prisma.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:'NON_SALE_CREATED',entityType:'NonSaleDispensing',entityId:item.id,newValue:{type,quantityLitres:qty.toFixed(3),reason}}});
 return NextResponse.json({ok:true,id:item.id,status:item.status});
}
