import {NextRequest,NextResponse} from 'next/server';
import {prisma} from '@/lib/prisma';
import {Prisma} from '@prisma/client';
import {requireUser} from '@/lib/auth/session';

export async function POST(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 const {id}=await params; const b=await req.json();
 let user; try{user=await requireUser(['SALESMAN'])}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==='FORBIDDEN'?403:401});}
 const shift=await prisma.shift.findFirst({where:{id,stationId:user.stationId,assignedUserId:user.id,status:'CLOSING'}});
 if(!shift)return NextResponse.json({error:'Shift not found or not in CLOSING state'},{status:400});
 const cashPaid=await prisma.payment.aggregate({where:{sale:{shiftId:id,stationId:user.stationId},method:'CASH',status:'COMPLETED'},_sum:{amount:true}});
 const refunds=await prisma.cashMovement.aggregate({where:{shiftId:id,type:'REFUND'},_sum:{amount:true}});
 const expenses=await prisma.cashMovement.aggregate({where:{shiftId:id,type:{in:['EXPENSE','CASH_OUT']}},_sum:{amount:true}});
 const cashIn=await prisma.cashMovement.aggregate({where:{shiftId:id,type:'CASH_IN'},_sum:{amount:true}});
 const adjustments=await prisma.cashMovement.aggregate({where:{shiftId:id,type:'ADJUSTMENT'},_sum:{amount:true}});
 const expected=new Prisma.Decimal(shift.openingCash).add(cashPaid._sum.amount||0).sub(refunds._sum.amount||0).sub(expenses._sum.amount||0).add(cashIn._sum.amount||0).add(adjustments._sum.amount||0);
 const actual=new Prisma.Decimal(String(b.actualCash??'0')).toDecimalPlaces(2); const diff=actual.sub(expected).toDecimalPlaces(2); const explanation=String(b.explanation||'').trim();
 if(actual.lt(0))return NextResponse.json({error:'Actual cash cannot be negative'},{status:400});
 if(!diff.eq(0)&&!explanation)return NextResponse.json({error:'Explanation required for cash difference',expected:expected.toFixed(2),difference:diff.toFixed(2)},{status:400});
 await prisma.$transaction(async tx=>{await tx.cashReconciliation.upsert({where:{shiftId:id},update:{expectedCash:expected,actualCash:actual,difference:diff,explanation:explanation||null,submittedBy:user.id,status:diff.eq(0)?'APPROVED':'EXPLAINED'},create:{shiftId:id,expectedCash:expected,actualCash:actual,difference:diff,explanation:explanation||null,submittedBy:user.id,status:diff.eq(0)?'APPROVED':'EXPLAINED'}}); await tx.shift.update({where:{id},data:{expectedCash:expected,closingCash:actual,difference:diff}}); await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:'CASH_RECONCILED',entityType:'Shift',entityId:id,newValue:{expected:expected.toFixed(2),actual:actual.toFixed(2),difference:diff.toFixed(2)}}});});
 return NextResponse.json({ok:true,expected:expected.toFixed(2),actual:actual.toFixed(2),difference:diff.toFixed(2)});
}
