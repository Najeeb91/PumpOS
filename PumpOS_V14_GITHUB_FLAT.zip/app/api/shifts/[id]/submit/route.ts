import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {requireUser} from "@/lib/auth/session";

export async function POST(_req:Request,{params}:{params:Promise<{id:string}>}){
 const {id}=await params;
 let user; try{user=await requireUser(["SALESMAN"])}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401});}
 const shift=await prisma.shift.findFirst({where:{id,stationId:user.stationId,assignedUserId:user.id,status:"CLOSING"},include:{reconciliation:true,cashRecon:true}});
 if(!shift)return NextResponse.json({error:"Shift not in CLOSING state"},{status:400});
 const activeNozzles=await prisma.nozzle.count({where:{isActive:true,machine:{stationId:user.stationId}}});
 if(shift.reconciliation.length!==activeNozzles) return NextResponse.json({error:"All fuel reconciliation lines are required before submission"},{status:400});
 const unresolvedVariance=shift.reconciliation.some(x=>x.status==="VARIANCE" && (!x.varianceExplanation || !x.varianceApprovedBy));
 const invalid=shift.reconciliation.some(x=>x.status!=="RECONCILED" && x.status!=="VARIANCE");
 if(invalid) return NextResponse.json({error:"Invalid fuel reconciliation line"},{status:400});
 if(unresolvedVariance) return NextResponse.json({error:"Every fuel variance must be explained and manager-approved before submission"},{status:400});
 if(!shift.cashRecon)return NextResponse.json({error:"Cash reconciliation is required"},{status:400});
 if(shift.cashRecon.status==="OPEN")return NextResponse.json({error:"Cash reconciliation is not submitted"},{status:400});
 await prisma.$transaction(async tx=>{
   await tx.shift.update({where:{id},data:{status:"PENDING_APPROVAL"}});
   await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:"SHIFT_SUBMITTED",entityType:"Shift",entityId:id,newValue:{status:"PENDING_APPROVAL"}}});
 });
 return NextResponse.json({ok:true});
}
