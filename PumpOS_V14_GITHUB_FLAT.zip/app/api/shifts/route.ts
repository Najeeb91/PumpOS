import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";
import { requireUser } from "@/lib/auth/session";

export async function POST(req: NextRequest) {
  const form = await req.formData();
  const action = String(form.get("action") || "");
  let user;
  try { user = await requireUser(["SALESMAN"]); } catch (e:any) { return NextResponse.json({error:e.message}, {status:e.message==="FORBIDDEN"?403:401}); }

  if (action === "start") {
    const openingCash = new Prisma.Decimal(String(form.get("openingCash") || "0"));
    const active = await prisma.shift.findFirst({ where: { stationId:user.stationId, status:{in:["OPEN","CLOSING","PENDING_APPROVAL"]} }});
    if (active) return NextResponse.redirect(new URL("/salesman", req.url));
    const last = await prisma.shift.findFirst({ where:{stationId:user.stationId}, orderBy:{shiftNumber:"desc"} });
    const nozzles = await prisma.nozzle.findMany({ where:{isActive:true, machine:{stationId:user.stationId}}});
    const previous = last ? await prisma.meterReading.findMany({where:{shiftId:last.id,readingType:"CLOSING"}}) : [];
    const shift = await prisma.$transaction(async tx => {
      const s = await tx.shift.create({data:{stationId:user.stationId,assignedUserId:user.id,shiftNumber:(last?.shiftNumber??0)+1,openingCash}});
      for (const n of nozzles) {
        const p = previous.find(x=>x.nozzleId===n.id);
        await tx.meterReading.create({data:{shiftId:s.id,nozzleId:n.id,readingType:"OPENING",meterValue:p?.meterValue ?? new Prisma.Decimal(0),recordedBy:user.id}});
      }
      await tx.auditLog.create({data:{stationId:user.stationId,userId:user.id,action:"SHIFT_STARTED",entityType:"Shift",entityId:s.id,newValue:{openingCash:openingCash.toString()}}});
      return s;
    });
    return NextResponse.redirect(new URL("/salesman", req.url));
  }

  if (action === "close") {
    const shiftId = String(form.get("shiftId") || "");
    await prisma.shift.updateMany({where:{id:shiftId,assignedUserId:user.id,status:"OPEN"},data:{status:"CLOSING"}});
    return NextResponse.redirect(new URL("/salesman", req.url));
  }

  return NextResponse.json({error:"Unknown action"}, {status:400});
}