import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
export default async function Home(){ const u=await getCurrentUser(); if(!u) redirect("/login"); redirect(u.role==="SALESMAN"?"/salesman":u.role==="MANAGER"?"/manager":"/owner"); }