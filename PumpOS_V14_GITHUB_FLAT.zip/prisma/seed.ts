import { PrismaClient, Prisma } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const station = await prisma.station.upsert({
    where:{code:"DEMO-01"},
    update:{},
    create:{name:"PumpOS Demo Station",code:"DEMO-01",address:"India"}
  });
  const salesman = await prisma.user.upsert({
    where:{stationId_phone:{stationId:station.id,phone:"9999999999"}},
    update:{passwordHash:"scrypt:PumpOS-Demo-Salt:7ff306d050c609b0fd6303d2d307f834835a48f81373ddefbc45f9c9bdbd856ecab8856e9c8960750bb271ef8d4083ed1d0becf44a61d246d051a9f38b4aa107",isActive:true},
    create:{stationId:station.id,name:"Demo Salesman",phone:"9999999999",passwordHash:"scrypt:PumpOS-Demo-Salt:7ff306d050c609b0fd6303d2d307f834835a48f81373ddefbc45f9c9bdbd856ecab8856e9c8960750bb271ef8d4083ed1d0becf44a61d246d051a9f38b4aa107",role:"SALESMAN"}
  });
  await prisma.user.upsert({
    where:{stationId_phone:{stationId:station.id,phone:"9999999998"}},
    update:{passwordHash:"scrypt:PumpOS-Demo-Salt:7ff306d050c609b0fd6303d2d307f834835a48f81373ddefbc45f9c9bdbd856ecab8856e9c8960750bb271ef8d4083ed1d0becf44a61d246d051a9f38b4aa107",isActive:true},
    create:{stationId:station.id,name:"Demo Manager",phone:"9999999998",passwordHash:"scrypt:PumpOS-Demo-Salt:7ff306d050c609b0fd6303d2d307f834835a48f81373ddefbc45f9c9bdbd856ecab8856e9c8960750bb271ef8d4083ed1d0becf44a61d246d051a9f38b4aa107",role:"MANAGER"}
  });
  await prisma.user.upsert({
    where:{stationId_phone:{stationId:station.id,phone:"9999999997"}},
    update:{passwordHash:"scrypt:PumpOS-Demo-Salt:7ff306d050c609b0fd6303d2d307f834835a48f81373ddefbc45f9c9bdbd856ecab8856e9c8960750bb271ef8d4083ed1d0becf44a61d246d051a9f38b4aa107",isActive:true},
    create:{stationId:station.id,name:"Demo Owner",phone:"9999999997",passwordHash:"scrypt:PumpOS-Demo-Salt:7ff306d050c609b0fd6303d2d307f834835a48f81373ddefbc45f9c9bdbd856ecab8856e9c8960750bb271ef8d4083ed1d0becf44a61d246d051a9f38b4aa107",role:"OWNER"}
  });

  const petrol = await prisma.fuelProduct.upsert({where:{stationId_code:{stationId:station.id,code:"PETROL"}},update:{},create:{stationId:station.id,name:"Petrol",code:"PETROL"}});
  const diesel = await prisma.fuelProduct.upsert({where:{stationId_code:{stationId:station.id,code:"DIESEL"}},update:{},create:{stationId:station.id,name:"Diesel",code:"DIESEL"}});
  await prisma.customer.upsert({where:{id:"demo-customer-1"},update:{},create:{id:"demo-customer-1",stationId:station.id,name:"Demo Fleet Customer",phone:"9999900000",vehicleNumber:"HR00AA0000",creditLimit:new Prisma.Decimal("50000"),currentBalance:new Prisma.Decimal("0")}});

  const machine = await prisma.machine.create({data:{stationId:station.id,name:"M1"}});
  const n1 = await prisma.nozzle.create({data:{machineId:machine.id,fuelProductId:petrol.id,nozzleNumber:1}});
  const n2 = await prisma.nozzle.create({data:{machineId:machine.id,fuelProductId:diesel.id,nozzleNumber:2}});

  await prisma.fuelPrice.createMany({data:[
    {stationId:station.id,fuelProductId:petrol.id,pricePerLitre:new Prisma.Decimal("94.500"),effectiveFrom:new Date()},
    {stationId:station.id,fuelProductId:diesel.id,pricePerLitre:new Prisma.Decimal("87.600"),effectiveFrom:new Date()}
  ]});

  console.log({station:station.code,salesman:salesman.phone,nozzles:[n1.id,n2.id]});
}
main().finally(()=>prisma.$disconnect());