# Database migration policy

This project is intended to use `prisma migrate dev` for development and `prisma migrate deploy` in production.

Do not use `prisma db push` against the production database.

Before the first production deployment:
1. Provision a fresh PostgreSQL database.
2. Run `npx prisma migrate dev --name init` locally against a disposable database and commit the generated SQL.
3. Review the generated SQL.
4. Apply with `npx prisma migrate deploy` in staging.
5. Run the automated tests and a reconciliation smoke test.
6. Only then deploy to production.

The schema in this V6 package is the source of truth; this marker exists to make the migration requirement explicit rather than pretending a hand-written migration is equivalent to Prisma's generated migration history.
