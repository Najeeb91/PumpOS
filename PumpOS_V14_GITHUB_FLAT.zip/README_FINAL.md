# PumpOS — MVP Control System

PumpOS is positioned as a **Fuel Station Shift Control & Reconciliation System**.

Core control chain:
`meter → litres → sales → payments → expected cash → actual cash → difference → accountability`

## Current locked controls
- Petrol and Diesel reconciled separately.
- No tolerance band: only `0.000 L` is reconciled.
- Amount ↔ litres supported; server recalculates and validates.
- Transaction-time price is locked on every sale.
- Split payments supported; completed payment sum must equal sale total.
- Bank-transfer reference/UTR is optional.
- Credit limit is enforced transactionally.
- Normal sales do not wait for manager approval.
- Shift approval is required only after closing controls pass.
- Completed financial records are immutable; corrections are VOID/REVERSAL with reason and audit.
- Cash expected value comes from authoritative Payment rows, including split payments.
- Meter rollover/reset/replacement and non-sale dispensing are explicit, auditable exceptions.
- Role hierarchy: OWNER → MANAGER → SALESMAN.
- Station isolation is enforced server-side.
- Idempotency keys are fingerprint-bound.
- Security headers and health endpoint are included.

## Production status
The application code and control design are substantially hardened, but **production readiness is not the same as ZIP integrity**. A real PostgreSQL migration must be generated and reviewed, dependencies must be installed, typecheck/tests/build must pass, and a real-station pilot must succeed before production use.


## Run
See `RUN.md` for Docker/local startup.
