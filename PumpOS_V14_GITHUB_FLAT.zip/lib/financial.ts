export type PaymentLine = { method: string; amount: string };

function cents(value: string): bigint {
  const s = String(value ?? "0").trim();
  if (!/^-?\d+(?:\.\d{1,2})?$/.test(s)) throw new Error("Invalid money value");
  const neg = s.startsWith("-");
  const t = neg ? s.slice(1) : s;
  const [whole, frac = ""] = t.split(".");
  const n = BigInt(whole) * 100n + BigInt((frac + "00").slice(0, 2));
  return neg ? -n : n;
}
function money(n: bigint): string {
  const neg = n < 0n; const x = neg ? -n : n;
  return `${neg ? "-" : ""}${x / 100n}.${(x % 100n).toString().padStart(2,"0")}`;
}

export function sumMoney(values: string[]): string { return money(values.reduce((a,v)=>a+cents(v),0n)); }
export function paymentsMatchSale(saleAmount: string, payments: PaymentLine[]): boolean { return sumMoney(payments.map(p=>p.amount)) === money(cents(saleAmount)); }
export function expectedCash(params:{openingCash:string;cashSales:string;cashRefunds?:string;expenses?:string;cashIn?:string;adjustments?:string}):string {
  let n=cents(params.openingCash)+cents(params.cashSales)-cents(params.cashRefunds??"0")-cents(params.expenses??"0")+cents(params.cashIn??"0")+cents(params.adjustments??"0");
  return money(n);
}
export function fuelVariance(opening:string,closing:string,sales:string,nonSale:string):string {
  const scale=1000n; const parse=(v:string)=>{const s=String(v).trim();const neg=s.startsWith('-');const t=neg?s.slice(1):s;const [w,f='']=t.split('.');const n=BigInt(w)*scale+BigInt((f+'000').slice(0,3));return neg?-n:n;};
  const n=parse(closing)-parse(opening)-parse(sales)-parse(nonSale); const neg=n<0n; const x=neg?-n:n; return `${neg?'-':''}${x/scale}.${(x%scale).toString().padStart(3,'0')}`;
}
