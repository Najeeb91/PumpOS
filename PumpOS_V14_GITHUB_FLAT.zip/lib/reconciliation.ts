import { Prisma } from "@prisma/client";

export function zero(n: Prisma.Decimal) {
  return n.eq(0);
}

export function calculateVariance(
  meterVolume: Prisma.Decimal,
  salesVolume: Prisma.Decimal,
  nonSaleVolume: Prisma.Decimal
) {
  return meterVolume.sub(salesVolume).sub(nonSaleVolume);
}