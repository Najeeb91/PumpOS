import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const protectedPath = ["/salesman", "/manager", "/owner", "/api/shifts", "/api/sales"] .some(p => req.nextUrl.pathname === p || req.nextUrl.pathname.startsWith(p + "/"));
  if (protectedPath && !req.cookies.get("pumpos_session")) return NextResponse.redirect(new URL("/login", req.url));
  return NextResponse.next();
}
export const config = { matcher: ["/salesman/:path*", "/manager/:path*", "/owner/:path*", "/api/shifts/:path*", "/api/sales/:path*"] };
