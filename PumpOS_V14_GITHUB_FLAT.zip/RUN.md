# PumpOS — Run Guide

## Fastest local run (Docker)

Requirements: Docker Desktop / Docker Engine.

1. Copy `.env.example` to `.env` if you want local non-container tooling.
2. Start PostgreSQL + app:
   `docker compose up --build`
3. In a separate terminal, initialize the database once:
   `docker compose exec app npx prisma db push`
4. Seed demo data in local/demo environments only:
   `docker compose exec app npx prisma db seed`
5. Open `http://localhost:3000`.

Demo credentials are documented in `README.md`. Replace them before any real deployment.

## Production

Use a managed PostgreSQL database, generate and review a real Prisma migration, then deploy with `prisma migrate deploy`. Do not use `db push` or demo seed credentials in production.
