# PumpOS Release Candidate

## Locked control model
- Meter → volume → sales → payments → expected cash → actual cash → variance → accountability.
- Petrol and Diesel remain separate for litres, value, and reconciliation. Only Grand Total Value may combine them.
- Fuel reconciliation has no tolerance: `0.000 L` is reconciled; any non-zero value is a variance.
- A fuel variance must be explained by the salesman and approved by a manager/owner before shift submission and final approval.
- Cash reconciliation uses authoritative completed Cash payment rows plus cash movements; split Cash + UPI does not inflate cash.
- Historical sale price is immutable.
- Financial corrections use VOID/REVERSAL with reason and audit. Balanced ADJUSTMENT is intentionally not enabled.
- Shift lifecycle: OPEN → CLOSING → PENDING_APPROVAL → CLOSED.

## Release gate
1. Install dependencies with the pinned package versions.
2. Run `npm run typecheck`.
3. Run `npm test`.
4. Run `npm run build`.
5. Run Docker/PostgreSQL smoke test.
6. Execute sale → closing → reconciliation → cash → variance explanation/approval → manager approval.
7. Replace demo credentials and configure production secrets before deployment.

## Current environment limitation
The source package has been statically hardened, but this environment has not successfully installed npm dependencies, so a real Next.js/Prisma build and database integration run remain pending external execution.
