# PumpOS MVP — Vertical Slice V3

Fuel Station Shift Control & Reconciliation System.

## Security layer added
- Real session-based authentication using an HttpOnly cookie.
- Password hashing with Node `crypto.scryptSync` (no extra auth dependency).
- Session records stored in PostgreSQL with expiry.
- Role-based authorization: OWNER / MANAGER / SALESMAN.
- Station isolation enforced from the authenticated user's station.
- Protected UI and API routes via Next.js middleware.
- Audit log on successful login and shift approval.
- No API route chooses the first salesman/manager anymore.

## Demo credentials after seed
- Salesman: `9999999999` / `123456`
- Manager: `9999999998` / `123456`
- Owner: `9999999997` / `123456`

Change these before production.

## Run
```bash
npm install
cp .env.example .env
# set DATABASE_URL
npm run db:push
npm run db:seed
npm run dev
```

Then open `/login`.

## Important production work still required
- Replace demo seed credentials.
- Add rate limiting / login lockout and CSRF protection for state-changing form endpoints.
- Add idempotency keys for financial writes.
- Add explicit amount-vs-litres consistency validation.
- Implement split payments and bank-transfer UTR/subtype.
- Implement atomic credit-limit enforcement and ledger updates.
- Add meter rollover/reset/replacement exception workflow.
- Add real Prisma migrations and backup/restore procedures.
- Add automated unit/integration/e2e tests.

## V4 financial controls added
- Split payments through `Payment[]` with server-side total validation.
- Credit sale requires a station-scoped customer and atomic limit checks inside the DB transaction.
- Credit ledger entry is created with balance-after snapshot.
- Every sale carries a unique idempotency key to prevent accidental duplicate submission.
- If both amount and litres are entered, server validates they match the locked transaction-time price.
- Bank transfer UTR/reference is optional; capture it when available.
- Salesman customer list is station-isolated.

**Important:** Run `prisma db push`/a proper migration after pulling these schema changes. This MVP still needs production-grade concurrency tests around credit updates and a dedicated payment-split UI instead of raw JSON entry.
