# PumpOS V6 — Financial Integrity Hardening

V6 focuses on correctness before adding more business features.

## Added
- Pure financial-domain calculations for expected cash and fuel variance.
- Automated tests for split-payment equality, paise-safe money totals, expected cash and exact no-tolerance fuel variance.
- `npm test` and `npm run typecheck` scripts.
- Explicit Prisma migration policy: production uses `prisma migrate deploy`, not `db push`.

## Important correction rule
A completed sale must remain financially balanced: the sum of completed payment lines must equal the sale gross amount. Any future sale adjustment must update the financial event model consistently; do not silently change only `Sale.grossAmount` while leaving payments unchanged.

## Still required before production
- Generate and commit the real Prisma initial migration against a disposable PostgreSQL database.
- Run tests with dependencies installed.
- Add database-backed concurrency tests for idempotency and credit limits.
- Add integration tests for VOID/REVERSAL, cash reconciliation and manager approval.
- Add meter rollover/reset/replacement exception workflow.
