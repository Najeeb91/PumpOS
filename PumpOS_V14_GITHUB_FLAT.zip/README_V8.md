# PumpOS V8 — Meter Exception Control

V8 adds controlled handling for dispenser meter rollover, reset and replacement. A lower closing meter is never silently accepted.

## Workflow
1. Salesman enters meter exception with type, reason and adjusted shift volume.
2. Manager/Owner explicitly approves the exception.
3. Reconciliation may use the approved adjusted volume.
4. If sales + approved non-sale does not equal that volume exactly, the nozzle remains VARIANCE.

This keeps unusual physical meter events visible and auditable rather than hiding them with a tolerance.
