# PumpOS V9 — Physical Exception Workflow

- Meter rollover/reset/replacement can be recorded explicitly and manager-approved.
- Approved meter exception provides the controlled adjusted shift volume used by reconciliation.
- Closing a lower meter is rejected unless an approved exception exists.
- Non-sale dispensing (test/calibration/maintenance/sample/other) is recorded separately and must be manager-approved before it counts in reconciliation.
- All exception creation/approval actions are audited.
